(function(){
    
  var entity = undefined;
  /*
  JSLitmus.test('Type: register + unregister new type', function() {
    var newPersonType = new VIE2.Type('PersonWithAge', 'Person', [
        {id       : 'age',
         datatype : 'Integer'
         }], {});
   VIE2.unregisterType('PersonWithAge');
  });

  JSLitmus.test('Model: create without props', function() {
    new VIE2.Entity();
  });
  
  JSLitmus.test('Model: create with props', function() {
    entity = new VIE2.Entity({
       a: 'Person',
       name : 'John Doe',
       description : 'This is a test'
   });
  });
  
  JSLitmus.test('Model: change props', function() {
    entity.set({
      name: 'Johnny The Doe',
      description : ['This is a test', 'This is another test']
   });
  });
  */
})();