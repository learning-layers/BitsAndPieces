
 // GLOBAL VARIABLES...
 
 var draw = null; // the SVG canvas
 var selectedRect=null;
 var xRect = null;
 var yRect=null;
 var selectedCirc=null;
 var selectedLabel=null;
 var selectedRectPisitionX=0;
 var selectedRectPisitionY=0;
 var selectedEntity = null;
 var selectedEntityRect = null;
 var xCirc = null;
 var yCirc=null;
 var currentLabel=null; 
 var currentFobj = null;
 var insideLabel=0;
 var labelPisitionX=0;
 var labelPisitionY=0;
 var labelCounter=0;
 var svgElements = new Array();
 var isDragging=0;
 var draggedEntity = null;
 var resizingCircle = false;
 
 	// constants to identify the border circles which was clicked
 var TOPLEFT = 1
 var TOPRIGHT = 2
 var BOTTOMLEFT = 3
 var BOTTOMRIGHT = 4
 
 // variables corresponding to each border circles
 
 var circTopLeft = null;
 var circTopRight = null;
 var circBottomLeft = null;
 var circBottomRight = null;
 
 // Left and right offset for the main svg canvas (bitsandpeaces)
 // The valuea are set after loading the bitsandpieces div
 //int the loadBrowzeCanvasmethod
 
 var LEFTOFFSET = 0;
 var TOPOFFSET = 0;
 
 
function clickOutside(event)
{	
	if ( ((event.pageX-LEFTOFFSET)>=selectedRect.attr('x'))  &&  
		 ((event.pageX-LEFTOFFSET)<= (selectedRect.attr('x') + 2*selectedCirc.attr('rx'))+3) && 
		 ((event.pageY-TOPOFFSET)>=selectedRect.attr('y'))  && 
		 ((event.pageY-TOPOFFSET)<= (selectedRect.attr('y') + 2*selectedCirc.attr('ry'))+3))	
        	return 0; //inside 
	else
		return 1; //outside	
}

function removeCircleAndEntity(event)
{
    if (event.keyCode==8 || event.keyCode==46) // if bakspace (8) or delete (46) keys are pressed
     {
        if (selectedCirc!=null) // delete selected circle
            {
                removeCircleFromArray(selectedCirc); 
                selectedCirc.remove();
                selectedLabel.remove();
		removeRectSmallCirc();
                labelCounter--;           
            }
        if (selectedEntity!=null)    
            {
               removeEntityFromAllCircles(ent);
               selectedEntity.remove(); 
               selectedEntityRect.remove();
            }
     }
}

function removeRectSmallCirc()
{	
	selectedRect.remove();
	circTopLeft.remove();
	circTopRight.remove();
	circBottomLeft.remove();
 	circBottomRight.remove();		
			
	selectedCirc=null
        selectedLabel=null;
	selectedRect = null;
	circTopLeft = null;
	circTopRight = null;
	circBottomLeft = null;
 	circBottomRight = null;
		
}

function unselectLabel()
{
    if (currentLabel!=null)
       {
        // the foreign object HTML text are content is placed inside 
        // the SVG text
        var n = currentFobj.getChild(0);
        newTextLabel=n.value;
        currentLabel.show();
        currentLabel.text(newTextLabel);
        currentFobj.remove();
        currentFobj=null;
        currentLabel=null;
       }
}

function unselectEntity()
{
  if (selectedEntity!=null)    
   {
      selectedEntity=null; 
      selectedEntityRect.remove();
      selectedEntityRect=null;
   }  
}

function unselectCircAndLabel(event)
{
        // If there is any selected ring label (insideLabel) then stop editing it
      if (insideLabel==0)                      
            unselectLabel();
         
         // if users clicks outside the rectangle, then remove small circles
	if(clickOutside(event))
          {
            removeRectSmallCirc();
          }   
} 

function stylySmallCircle(circ, type)
{
	switch (type)
	{
            case TOPLEFT:{ circ.style('cursor', 'nw-resize');break;}
            case TOPRIGHT:{ circ.style('cursor', 'ne-resize');break;}
            case BOTTOMLEFT:{ circ.style('cursor', 'sw-resize');break;}
            case BOTTOMRIGHT:{ circ.style('cursor', 'se-resize');break;}
	}
	
} 


function drawSmallCircle(X,Y,bigCirc,bigRect,idSmallCic)
{
	var circ = draw.circle(10).attr({ fill: 'blue' }).stroke({ width: 0.3 });
	circ.attr({ cx:X,cy:Y});
	circ.on('mousedown', function() {
		
		xMouseDown = event.pageX;
		yMouseDown = event.pageY;
		initialRectXSize = bigRect.attr('width');
		initialRectYSize = bigRect.attr('height');
		initialRectX = bigRect.attr('x');
		initialRectY = bigRect.attr('y');
		
		document.getElementById("bitsandpeaces").onmousemove= function(event) {	
		
			// Resizing the rectangle
                        
		resizingCircle = true; // this is usefull for the onmouseup event to stop
                                       //resizing the circle while moving the mouse
		var newRectXsize = Math.abs(initialRectXSize + (event.pageX-xMouseDown));
		var newRectYsize = Math.abs(initialRectYSize + (event.pageY-yMouseDown));
		
				
		if ((idSmallCic==BOTTOMLEFT) || (idSmallCic==TOPLEFT))
			{
					// crossing left border starting from the left border
				if((event.pageX-LEFTOFFSET)<initialRectX) 
					{
						newRectXsize = Math.abs(initialRectXSize + Math.abs(event.pageX-LEFTOFFSET-initialRectX));
						bigRect.attr('x',(event.pageX-LEFTOFFSET));
					}
				else
					{
						newRectXsize = Math.abs(initialRectXSize + -Math.abs(event.pageX-LEFTOFFSET-initialRectX));
						// crossing right border, coming from the left border
						if (!((event.pageX-LEFTOFFSET)> (initialRectX+initialRectXSize))) 
							bigRect.attr('x',(event.pageX-LEFTOFFSET));
	
					}
			}
			
		if ((idSmallCic==TOPLEFT) || (idSmallCic==TOPRIGHT))
			{
				// crossing top border starting from the top border
				if((event.pageY-TOPOFFSET)<initialRectY)
					{
						newRectYsize = Math.abs(initialRectYSize + Math.abs(event.pageY-TOPOFFSET-initialRectY));
						bigRect.attr('y',(event.pageY-TOPOFFSET));
					}
				else // crossing bottom border starting from the top border
					{
						newRectYsize = Math.abs(initialRectYSize + -Math.abs(event.pageY-TOPOFFSET-initialRectY));
						if (!((event.pageY-TOPOFFSET)> (initialRectY+initialRectYSize)))
							bigRect.attr('y',(event.pageY-TOPOFFSET));
					}
			}			
			
		if ((idSmallCic==TOPRIGHT) || (idSmallCic==BOTTOMRIGHT))
			{
				// crossing left border starting from the right border
				if((event.pageX-LEFTOFFSET)<initialRectX) 
						bigRect.attr('x',(event.pageX-LEFTOFFSET));
			}			
	
		if ((idSmallCic==BOTTOMLEFT) || (idSmallCic==BOTTOMRIGHT))
			{
				// crossing top border starting from the bottom border
				if((event.pageY-TOPOFFSET)<initialRectY) 
						bigRect.attr('y',(event.pageY-TOPOFFSET));
			}				
	
		
		bigRect.size(newRectXsize,newRectYsize); // final resizing of the rectangle
		
			// Resizing the (big) circle: changing the radius			
		var newCircXRad = newRectXsize/2;
		var newCircYRad = newRectYsize/2; 
		bigCirc.attr('rx',newCircXRad);
		bigCirc.attr('ry',newCircYRad);
		bigCirc.attr('x',bigRect.attr('x'));
		bigCirc.attr('y',bigRect.attr('y'));
		
                    // Changinh the center of the big circle				
		bigCirc.attr('cx',(bigRect.attr('x')+(newRectXsize/2)) );
		bigCirc.attr('cy',(bigRect.attr('y')+(newRectYsize/2)) );
                
		// Setting the new dragging border of the circle Label                 
                setTextDragLimit(selectedLabel,bigCirc.attr('cx'),bigCirc.attr('cy'),bigCirc.attr('rx')*2,bigCirc.attr('ry')*2);

		// Adjusting the locaton of the border circles (small circles)			
		if (circTopLeft!=null)
			{
				circTopLeft.attr('cx',bigRect.attr('x'));
				circTopLeft.attr('cy',bigRect.attr('y'))
			}

		if (circTopRight!=null)
			{
				circTopRight.attr('cx',bigRect.attr('x')+newRectXsize);
				circTopRight.attr('cy',bigRect.attr('y'))
			}

		if (circBottomLeft!=null)
			{
				circBottomLeft.attr('cx',bigRect.attr('x'));
				circBottomLeft.attr('cy',bigRect.attr('y')+newRectYsize)
			}	
			
		if (circBottomRight!=null)
			{
				circBottomRight.attr('cx',bigRect.attr('x')+newRectXsize);
				circBottomRight.attr('cy',bigRect.attr('y')+newRectYsize)
			}
              // The circle resizing stops when mouseup event is triggered 
	  }

	})
	
	stylySmallCircle(circ, idSmallCic) // stylying small circles
	return circ;
}

function clickCircle(circ,text)
{
	// if there is another selected circle, then unselect it by 
        // removing the rectangle and small circles...
	if (selectedCirc!=null)
		removeRectSmallCirc();
	
	var radiusx = circ.attr('rx');
	var radiusy = circ.attr('ry');
	
	var x = circ.attr('cx');
	var y = circ.attr('cy');
	xRect = radiusx*2;
	yRect = radiusy*2;
	
	var im1 = draw.rect(xRect,yRect).attr({ fill: 'none' }).stroke({ width: 0.3,color:'blue' });
	im1.center(x,y);
	//im1.draggable();	
	selectedRect = im1;
	selectedCirc = circ;
        selectedLabel = text;
	
	// Drawing small circles on the corners of the rectangles
	var topLeftX = x - radiusx;
	var topLeftY = y - radiusy;
	circTopLeft = drawSmallCircle(topLeftX,topLeftY,circ,im1,TOPLEFT);
		
	var topRigtX = x + radiusx;
	var topRigtY = y - radiusy;
	circTopRight = drawSmallCircle(topRigtX,topRigtY,circ,im1,TOPRIGHT);
	
	var bottomLeftX = x - radiusx;
	var bottomLeftY = y + radiusy;
	circBottomLeft = drawSmallCircle(bottomLeftX,bottomLeftY,circ,im1,BOTTOMLEFT);
	
	var bottomRightX = x + radiusx;
	var bottomRightY = y + radiusy;
	circBottomRight = drawSmallCircle(bottomRightX,bottomRightY,circ,im1,BOTTOMRIGHT);	
}	


function clickRect(rect)
{
	selectedRect = rect;
	xRect = selectedRect.attr('x');
	yRect = selectedRect.attr('y');
	
	
	document.getElementById("bitsandpeaces").onmousemove= function(event) {	
		var newXsize = event.pageX-xRect;
		var newYsize = event.pageY-yRect;

		selectedRect.size(newXsize,newYsize);
					
	}	
}


function canvasDoubleClick(event)
{
    
    if (selectedEntity==null && currentFobj==null)
        drawCircle(event);
   /* else
        alert ("entity double clicked")
           opens the selectedEntity with the 
           right application 
*/

}


function drawCircle(ev)
{ 
	var x = ev.pageX-LEFTOFFSET;
	var y = ev.pageY-TOPOFFSET;
	var diameter = 200;
        var circlePositionInArray;
        var entitiesInitialPositions = new Array();
        var sharedEntities = new Array();
	
       // Drawing the Label for the Circle 
       var text = drawTag(x,y,diameter);

       // Drawing the Circle 
	var circ = draw.circle(diameter).attr({ fill: 'transparent',cx: x, cy: y }).stroke({ width: 3 });
        circ.back();
        
        //var circ = draw.circle(diameter).attr({ fill: 'white',cx: x, cy: y }).stroke({ width: 3 });        
        //circ.back();
	
        circ.draggable({minX:0,minY:400,maxX:800,maxY:800 });
	circ.style('cursor','move');
        circlePositionInArray = addCircleIntoArray(circ, text);    
        
        
        // MANAGING EVENTS FOR THE CIRCLE
	circ.click(function() {
		clickCircle(circ,text);
                //insideCircle(ev.pageX-LEFTOFFSET,ev.pageY-LEFTOFFSET,circ)
               })	             

        // When the circle moves, the label should also move
        
       circ.dragstart = function() {
           
           
           // keeps the initial coordinates of the label and of each element 
           // inside the circle so that they can be dragger with the circle
           labelPisitionX=text.attr('x');
           labelPisitionY=text.attr('y');
           
           // Array entitiesInitialPositions stores the initial position off all 
           // entities that are inside a circle, so that they can be dragged 
           // with the circle
           
           for(var i=0;i<svgElements.length;i++) // getting the position of the circle in svgElements
               if (svgElements[i].svg==circ)
                 {  
                    circlePositionInArray=i;
                    break;
                 }  
         
           var entPos;
           for (var i=0; i<svgElements[circlePositionInArray].entities.length;i++)
            {
              entPos = new Object();
              entPos.x = svgElements[circlePositionInArray].entities[i].svg.attr('x'); 
              entPos.y = svgElements[circlePositionInArray].entities[i].svg.attr('y'); 
              entitiesInitialPositions.push(entPos);
            }
           
            // If there are circles selected (in this case a rectanlge is shown 
            // around this circle as well as small circles on its corders
           if(selectedRect!=null){
               
               //If the selected circle is not the one which has been clicked
               // it is necessary to unselect it, by removing the rectangle and 
               // the small circles around it
               if (selectedCirc!=circ)
                   removeRectSmallCirc();
               else{
                selectedRectPisitionX=selectedRect.attr('x');
                selectedRectPisitionY=selectedRect.attr('y');                
               }
            }          
            //sharedEntities = getListOfSharedEntities(circ);              
        }
        
        // drags the label and each element inside the circle along with the circle
       circ.dragmove = function(delta, event) { 
       text.move(labelPisitionX+delta.x,labelPisitionY+delta.y);  
       dragEntitiesWithCircle(circlePositionInArray,delta,entitiesInitialPositions);
       //protectSharedEntitiesInCircDragging(sharedEntities,circ);
         
         // drags the selected rectangle and small circles with the big circle
         if(selectedRect!=null)
           {
               selectedRect.move(selectedRectPisitionX+delta.x,selectedRectPisitionY+delta.y);
               
               circTopLeft.move(selectedRectPisitionX+delta.x,selectedRectPisitionY+delta.y);
               circTopRight.move((selectedRectPisitionX+delta.x+2*circ.attr('rx')),selectedRectPisitionY+delta.y);
               circBottomLeft.move(selectedRectPisitionX+delta.x,(selectedRectPisitionY+delta.y+2*circ.attr('ry')));
               circBottomRight.move((selectedRectPisitionX+delta.x+2*circ.attr('rx')),(selectedRectPisitionY+delta.y+2*circ.attr('ry')));     
           }
        } 

    circ.dragend = function(delta, event) {
        
        circ.draggable({minX:0,minY:400,maxX:800,maxY:800 });
        sharedEntities.length =0;
        
        
        
        setTextDragLimit(text,circ.attr('cx'),circ.attr('cy'),circ.attr('rx')*2,circ.attr('ry')*2);
        // Cleanning the entitiesInitialPositions Array
        entitiesInitialPositions.length = 0;
        updateEntitiesInCircles();
        }
    updateEntitiesInCircles();
    //text.dispatchEvent('click');
}


function protectSharedEntitiesInCircDragging(sharedEntities,circ)
{
  //alert("Inside")
  
  var limitX, limitY; 
  for (i=0;i<sharedEntities.length;i++)
   {
      limitX = sharedEntities[i].attr('x') + sharedEntities[i].attr('width')/2;
      limitY = sharedEntities[i].attr('y') + sharedEntities[i].attr('height')/2;
 
 
      //limitX = sharedEntities[i].attr('x') ;
      //limitY = sharedEntities[i].attr('y');
 
      if(!insideCircle(limitX,limitY,circ))
        {
            alert("found!!")
            //circ.fixed();
        }  
        
      //alert("Entrou no protect. Shared: "+sharedEntities.length + " limitX "+ 
        //  limitX + " limitY " + limitY + " cx "+ circ.attr('cx') + " cy " + circ.attr('cy'));    
   }       
}


/*
     var cx = x+draggedEntity.attr('width')/2;
    var cy = y+draggedEntity.attr('height')/2;
    
 **/

function drawTag(xCirc,yCirc,diameterCirc)
{
    
    // the coordinates of the label
    x = xCirc-30;
    y = yCirc-diameterCirc/2-30;
    
    
    labelCounter++;
    var text = draw.text("Concept "+labelCounter);
    text.move(x,y);

        // When the user clicks on the SVG text, the SVG text is edited:
        // (1) A Foreign object is created (HTML textarea) 
        // (2) This textarea replaces the SVG text
    text.click(function() {
       // alert("Entrou!!")
        
        if (currentLabel!=null && currentLabel!=text)
            unselectLabel();
            
        var labelText=text.content;
        currentLabel = text; 
        insideLabel=1; // to say that the text is being edited
                
        text.hide();  // hiding the current SVG text       
                
               // replacing the SVG Text with the HTML textarea (foreignobject)
        var fobj = draw.foreignObject(200,100).attr({id: 'fobj'})
        fobj.appendChild("textarea", {id: 'mytextarea', rows:'4', cols:'15',innerHTML: labelText})
        fobj.move(currentLabel.attr('x'),currentLabel.attr('y'));

               // To say that the mouse is outside the textare
               // thus, if the user clicks outside the textarea, the textarea 
               // content is inserted into the SVG text
               // this is done so that the dragging function can work smothly
        fobj.mouseout(function() { 
            insideLabel=0;
            }) 
            currentFobj=fobj;
       })               
    
          // The label is draggable but not too far away from the circle
    setTextDragLimit(text,xCirc,yCirc,diameterCirc,diameterCirc)
    return text;
}


function setTextDragLimit(text,xCirc,yCirc,xCircDiameter,yCircDiameter)
{
    var minDragX = xCirc-(xCircDiameter/2+70);
    var minDragY = yCirc-(yCircDiameter/2+70);
    var maxDragX = xCirc+(xCircDiameter/2+70);
    var maxDragY = yCirc+(yCircDiameter/2+70);  
    text.draggable({minX:minDragX,minY:minDragY,maxX:maxDragX,maxY:maxDragY });
}


function clickEntity(ent,event)
{        
    var xIm = ent.attr('x');
    var yIm = ent.attr('y');        
    
    var rect = draw.rect(ent.attr('width')+5,ent.attr('width')+5).attr({ fill: 'none' }).stroke({ width: 0.5,color:'blue' });
    rect.attr({ x: xIm, y: yIm });
    selectedEntity = ent;
    selectedEntityRect = rect;
    
    // If there any circle is selected(selectedRect), this circle is unselected
    // by removing unselecting the corresponding label (if it is selected) 
    // and by removing the small circle, no matter if the user clicked 
    // in an entity which is inside the circle
    if(selectedRect!=null)
      {
         if (insideLabel!=0)
             unselectLabel(); 
         removeRectSmallCirc() 
      }  
    
}


function loadOrganizeCanvas()
{
        
 
        // Setting global variables for Left and right
        //  offset for the main svg canvas (bitsandpeaces)
       var el=document.getElementById("bitsandpeaces");
       LEFTOFFSET = el.offsetLeft;
       TOPOFFSET = el.offsetTop;                        
       draw = SVG('bitsandpeaces'); // the SVG canvas
        
        
        //LOADING THE BROWSE CANVAS
        
        
        //var im1 = draw.rect(30,30).attr({ fill: 'red' }).stroke({ width: 2 });
        var im1 = draw.image('images/collections.ico', 50, 50)
        
	im1.attr({ x: 50, y: 50 });
	im1.draggable();
        im1.dragstart=function() {isDragging=1;draggedEntity=im1} 
        im1.click(function() {clickEntity(im1);})
        //im1.dragend = function(delta, event) {dropElement()}
        
	
	//var im2 = draw.rect(30,30).attr({ fill: 'green' }).stroke({ width: 2 });
        var im2 = draw.image('images/read.ico', 50, 50)
	im2.attr({ x: 100, y: 50 });
	im2.draggable();
        im2.dragstart=function() {
		isDragging=1;
                draggedEntity=im2;
               }
        im2.click(function() {
		clickEntity(im2);
               })
        //im2.dragend = function(delta, event) {dropElement()}

	//var im3 = draw.rect(30,30).attr({ fill: 'blue' }).stroke({ width: 2 });
        var im3 = draw.image('images/settings.ico', 50, 50)
	im3.attr({ x: 150, y: 50 });
	im3.draggable();
        im3.dragstart=function() {
		isDragging=1;
                draggedEntity=im3;
               }	
        im3.click(function() {
		clickEntity(im3);
               })
        //im3.dragend = function(delta, event) {dropElement()}

        //var im4 = draw.rect(30,30).attr({ fill: 'yellow' }).stroke({ width: 2 });
        var im4 = draw.image('images/Trash.ico', 50, 50)
	im4.attr({ x: 200, y: 50 });
	im4.draggable();
        im4.dragstart=function() {
		isDragging=1;
                draggedEntity=im4;
               }
        im4.click(function() {
		clickEntity(im4);
               })
        //im4.dragend = function(delta, event) {dropElement()}
        
        
	var separationLine = draw.line(0, 400, 800, 400).stroke({ width: 1 })
}



function updateEntitiesInCircles()
{
    var i,j,k,ent,x,y;
    
    
    for(i=0;i<svgElements.length;i++)
     {  
         numberOfEntities = svgElements[i].entities.length;
         for(j=0;j<numberOfEntities;j++)
          { 
            ent = svgElements[i].entities[j].svg; 
            // x and y store the coordinates of the center of the entity(image)
            x = ent.attr('x') + ent.attr('width')/2;
            y = ent.attr('y')+ ent.attr('height')/2;
            
            
            // Remove from the Entity list of a circle
            // all the elements which are now outside the circle are, 
            // after the circle has been dragger
            if(!insideCircle(x,y,svgElements[i].svg)) 
              {
                svgElements[i].entities.splice(j,1);  
                j--;
                numberOfEntities--;
                
               // alert("Removeu. i = "+i+" j = "+j +" numberOfEntities: "+numberOfEntities + 
               //     " x = "+x+" y= "+y+" cx = "+svgElements[i].svg.attr('cx')+" cy = "+svgElements[i].svg.attr('cy')+
               // " rx = "+svgElements[i].svg.attr('rx')+" ry = "+svgElements[i].svg.attr('ry'));
              }  

            // Adds the Entity to the entity list of every circle
            // inside of which the entity is now  
            // after the circle has been dragger
            
            for(k=0;k<svgElements.length;k++)
             {   
                 
                 if(insideCircle(x,y,svgElements[k].svg) && (isEntityInACircleInArray(k,ent)==-1))
                  {
                      svgElements[k].entities.push(newEntity(x,y,ent));                      
                  }                        
             }   
          }   
     }   
}

function newEntity(x,y,entSvg)
{
    ent = new Object();
    ent.x=x;
    ent.y=y;
    ent.svg=entSvg;
    
    return ent;
}


function getListOfSharedEntities(circ)
{
    var sharedEnt = new Array();
    var i, j;
    
    for(i=0; i< svgElements.length;i++)
     {
       if(svgElements[i].svg==circ)  
        {
            for (j=0;j<svgElements[i].entities.length;j++)
              {
                var isInOtherCirc = isEntityInOtherCircleInArray(svgElements[i].entities[j].svg,i)
                if(isInOtherCirc)
                 {
                   //alert("Found shared")
                   sharedEnt.push(svgElements[i].entities[j].svg); 
                 } 
                      
              }  
        }   
     }     
     //alert("Going to finish")
     //alert("Number of Share entities Found "+sharedEnt.length);
     
   return sharedEnt;   
}


function isEntityInOtherCircleInArray(ent,posCurrentCirc)
{
  var i;
  var result=false;
  
  //alert("isEntityInOtherCircleInArray -inicio");
  for(i=0; i<=svgElements.length;i++)
   {
     if ((i!=posCurrentCirc) && (isEntityInACircleInArray(i,ent)!=-1)) 
      {
         result = true;
         break;
      }   
   }   
  // alert("isEntityInOtherCircleInArray -FIM: "+result);
   return result;
}



function dragEntitiesWithCircle(circlePositionInArray,delta,entitiesInitialPositions)
{    
    var x;
    var y;
    
    for (var i=0; i<svgElements[circlePositionInArray].entities.length;i++)
     {
       x = entitiesInitialPositions[i].x + delta.x;
       y = entitiesInitialPositions[i].y + delta.y;
    
       svgElements[circlePositionInArray].entities[i].svg.move(x,y);
       svgElements[circlePositionInArray].entities[i].x = x;
       svgElements[circlePositionInArray].entities[i].y = y;
     }
}


function addCircleIntoArray(circ, label) 
{         
    circ1=new Object(); 
    
    circ1.cx = circ.attr('cx');
    circ1.cy = circ.attr('cy'); 
    circ1.rx = circ.attr('rx'); 
    circ1.ry = circ.attr('ry'); 
    circ1.svg = circ; 
    circ1.label = new Object(); 
    circ1.label.x = label.x; 
    circ1.label.y = label.y; 
    circ1.label.content = label.content; 
    circ1.label.svg= label;     
    circ1.entities = new Array();
    
    var pos = svgElements.push(circ1) - 1;      
    return pos;
} 

function addEntityIntoCircleInArray(entity, circle, pos) 
{   
   entity.next = svgElements[pos].entities;
   svgElements[i].entities=entity;
} 


function removeCircleFromArray(circ) 
{
   // removing all entities from the circle

   var i,j;
   for (i=0;i<svgElements.length;i++)
    {  
     if (svgElements[i].svg==circ) // finds the circle in array
       {          
         var numberOfEntities = svgElements[i].entities.length;  
         for(j=0;j<numberOfEntities;j++) // finds all entities
           {
            var ent = svgElements[i].entities[0].svg;
            svgElements[i].entities.splice(0,1);
                // If the entity is not inside any other circle
                // then it should be removed from the screen

            if (!isEntityInAnyCircleInArray(ent))
                ent.remove();               
           }  
         svgElements.splice(i,1);  //removing circle form array
         break;
       }  
    }
} 

function removeEntityFromCircleInArray(arrayPos, ent) 
{
    var i;
    
    for(i=0; i<svgElements[arrayPos].entities.length;i++)
      {  
       if(svgElements[arrayPos].entities[i].svg==ent)
        {   
          svgElements[arrayPos].entities.splice(i,1); 
          //break;
        }  
      }
}   
  
function removeEntityFromAllCircles(ent) 
{
    var i;
    
    for(i=0; i<svgElements.length;i++)
      {  
        removeEntityFromCircleInArray(i, ent)
          
      }
}


function isEntityInACircleInArray(arrayPos,ent) 
{
    //alert("Entered isEntityInACircleInArray")
    var i,result = -1;
    for(i=0; i<svgElements[arrayPos].entities.length;i++)
      {          
        if(svgElements[arrayPos].entities[i].svg==ent)
        {
            result=i;
            break;
        }     
      }  
      //alert("Exiting sEntityInACircleInArray. result: "+result);
    return result;
}


function isEntityInAnyCircleInArray(ent) 
{
    var i,result = false;
    for(i=0; i<svgElements.length;i++)
     {
        if (isEntityInACircleInArray(i,ent)!=-1)
          {  
             result = true;
             break;
          }   
     }
    return result;
} 



function insideCircle(x,y,circ)
{
  var cx = circ.attr('cx');
  var cy = circ.attr('cy');
  var rx = circ.attr('rx');
  var ry = circ.attr('ry');
  
  var inside = Math.pow(((x-cx)/rx),2) + Math.pow(((y-cy)/ry),2);
  if(inside<=1){
      //alert("Inside");
      return true;
    }
  else{
      //alert("Outside");
      return false;
    }
}


function canvasMouseUp(event)
{
    
     if(resizingCircle)
     {                  
       document.getElementById("bitsandpeaces").onmousemove=null;  
       updateEntitiesInCircles();
       resizingCircle = false;
     }       
     
   if (isDragging==1)
       dropElement();
}

function dropElement()
{
//alert("Entere. isDragging = "+isDragging)  
    var x = draggedEntity.attr('x');
    var y = draggedEntity.attr('y');


    // the image will only be considered inside a circle, only 
    //  if its center is inside the circle�
    var cx = x+draggedEntity.attr('width')/2;
    var cy = y+draggedEntity.attr('height')/2;
    
    //alert("X: "+x+" Y: "+y+" cx: "+cx+ " cy: "+cy)
    var ent;
    
   if (isDragging!=0) // an entity is being dragger
    {      
        // looks for every circle where the entity is being dropped
      for(var i=0; i<svgElements.length;i++)
       {
                // if the entity is being dropped within this circle...
         if(insideCircle(cx,cy,svgElements[i].svg))
            {
                
              if(isEntityInAnyCircleInArray(draggedEntity))  
               {     
                // remove the entity from all other circles it is not positioned 
                // inside of anymore
                for(var ii=0; ii<svgElements.length; ii++)
                {
                    if ((isEntityInACircleInArray(ii,draggedEntity)!=-1) &&(!insideCircle(cx,cy,svgElements[ii].svg)))
                    {
                        removeEntityFromCircleInArray(ii,draggedEntity);   
                    }
                }                 
                  
               }  
                  
                // the entity is added to the circles element list
                // but only if it is not already there
              if (isEntityInACircleInArray(i,draggedEntity)==-1)
                {
                    ent = newEntity(x,y,draggedEntity)
                    svgElements[i].entities.push(ent);
                }
            } 
       }       
      isDragging=0;
      draggedEntity=null;
    }   
    
       // Stops the onmousemove event (which is activated when resizing circles)
       // Therefore, onmouseup (which calls this dropelement Method) this onmousemove is stopped. This is usefull to end
       // the circle resizing
    
/*    
    if(resizingCircle)
     {         
       document.getElementById("bitsandpeaces").onmousemove=null;  
       updateEntitiesInCircles();
       resizingCircle = false;
     }   
  */      
    
}
